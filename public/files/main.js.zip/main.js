"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const fs_1 = require("fs");
const INPUTFILEPATH = "input.json";
const OUTPUTFILEPATH = "output.json";
allocateSchools(INPUTFILEPATH, OUTPUTFILEPATH);
function allocateSchools(inputFilePath, outputFilePath) {
  const input = JSON.parse((0, fs_1.readFileSync)(inputFilePath, "utf-8"));
  const { schools, students } = input;
  const studentScores = {};
  students.forEach((student) => {
    studentScores[student.id] = schools.reduce(
      (acc, school) => {
        const score = calculateWeightage(student, school);
        acc.scores.push(score);
        acc.schools.push(school.name);
        return acc;
      },
      { scores: [], schools: [] }
    );
    const ranking = studentScores[student.id];
    const [a, b] = sortParallelArrays(ranking.scores, ranking.schools, "desc");
    ranking.scores = a;
    ranking.schools = b;
  });
  const schoolAllocation = {};
  schools.forEach((school) => {
    Object.entries(studentScores).forEach(([studentId, ranking]) => {
      const index = ranking.schools.indexOf(school.name);
      if (index !== -1) {
        if (!schoolAllocation[school.name]) {
          schoolAllocation[school.name] = {
            scores: [],
            students: [],
            maxAllocation: school.maxAllocation,
          };
        }
        schoolAllocation[school.name].scores.push(ranking.scores[index]);
        schoolAllocation[school.name].students.push(parseInt(studentId));
      }
    });
    const ranking = schoolAllocation[school.name];
    const [a, b] = sortParallelArrays(ranking.scores, ranking.students, "desc");
    ranking.scores = a;
    ranking.students = b;
  });
  let slots = schools.reduce((acc, school) => {
    acc += school.maxAllocation;
    return acc;
  }, 0);
  const studentIds = Object.keys(studentScores).map((id) => parseInt(id));
  let pointer = 0;
  const allocation = {};
  while (slots > 0 && studentIds.length > 0) {
    const studentId = studentIds[pointer];
    const studentScore = studentScores[studentId];
    const schoolName = findBestSchool(
      studentScore,
      Object.keys(schoolAllocation)
    );
    if (!schoolName) {
      pointer++;
      if (pointer >= studentIds.length) {
        pointer = 0;
      }
      continue;
    }
    let rankOne = 0;
    while (
      !studentIds.includes(schoolAllocation[schoolName].students[rankOne])
    ) {
      rankOne++;
    }
    const firstRankingStudent = schoolAllocation[schoolName].students[rankOne];
    if (
      firstRankingStudent === studentId &&
      schoolAllocation[schoolName].maxAllocation > 0
    ) {
      if (!allocation[schoolName]) {
        allocation[schoolName] = [];
      }
      allocation[schoolName].push(studentId);
      studentIds.splice(pointer, 1);
      slots--;
      schoolAllocation[schoolName].maxAllocation--;
      if (schoolAllocation[schoolName].maxAllocation <= 0) {
        delete schoolAllocation[schoolName];
      }
    } else {
      pointer++;
    }
    if (pointer >= studentIds.length) {
      pointer = 0;
    }
  }
  const output = Object.keys(allocation)
    .sort()
    .map((schoolName) => ({
      [schoolName]: allocation[schoolName],
    }));
  (0, fs_1.writeFileSync)(outputFilePath, JSON.stringify(output, null, 2));
}
function calculateDistance(point1, point2) {
  const [x1, y1] = point1;
  const [x2, y2] = point2;
  return Math.sqrt(Math.pow(x1 - x2, 2) + Math.pow(y1 - y2, 2));
}
// Calculate the weightage score for a student for a particular school
function calculateWeightage(student, school) {
  let score = 0;
  // Distance weightage (50%)
  const distance = calculateDistance(student.homeLocation, school.location);
  const distanceScore = 50 / (1 + distance);
  score += distanceScore;
  // Alumni weightage (30%)
  if (student.alumni === school.name) {
    score += 30;
  }
  // Volunteer weightage (20%)
  if (student.volunteer === school.name) {
    score += 20;
  }
  return score;
}
function sortParallelArrays(arrayToSortBy, parallelArray, dir = "asc") {
  if (arrayToSortBy.length !== parallelArray.length) {
    throw new Error("Arrays must have the same length");
  }
  // Create an array of index-value pairs
  const indexValuePairs = arrayToSortBy.map((value, index) => ({
    index,
    value,
  }));
  // Sort the index-value pairs based on the values
  indexValuePairs.sort((a, b) => {
    if (dir === "asc") {
      if (a.value < b.value) return -1;
      if (a.value > b.value) return 1;
      return 0;
    } else {
      if (a.value < b.value) return 1;
      if (a.value > b.value) return -1;
      return 0;
    }
  });
  // Use the sorted indices to reorder both arrays
  const sortedArrayToSortBy = indexValuePairs.map(
    (pair) => arrayToSortBy[pair.index]
  );
  const sortedParallelArray = indexValuePairs.map(
    (pair) => parallelArray[pair.index]
  );
  return [sortedArrayToSortBy, sortedParallelArray];
}
function findBestSchool(schoolRanking, availableSchools) {
  for (const school of schoolRanking.schools) {
    if (availableSchools.includes(school)) {
      return school;
    }
  }
  return null;
}
